const express = require('express');
const router = express.Router();
const { getDB } = require('../config/db');
const { ObjectId } = require('mongodb');
const verifyToken = require('../middleware/verifyToken');
const verifyAdmin = require('../middleware/verifyAdmin');
const verifyDoctor = require('../middleware/verifyDoctor');

// POST /api/appointments — book an appointment (patient)
router.post('/', verifyToken, async (req, res) => {
  try {
    const db = getDB();
    const appointment = {
      ...req.body,
      patientEmail: req.user.email,
      appointmentStatus: 'pending',
      paymentStatus: 'unpaid',
      createdAt: new Date(),
    };
    const result = await db.collection('appointments').insertOne(appointment);
    res.status(201).json({ insertedId: result.insertedId, message: 'Appointment booked' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// GET /api/appointments/patient — patient's own appointments
router.get('/patient', verifyToken, async (req, res) => {
  try {
    const db = getDB();
    const { page = 1, limit = 8 } = req.query;
    const skip = (parseInt(page) - 1) * parseInt(limit);
    const query = { patientEmail: req.user.email };
    const [appointments, total] = await Promise.all([
      db.collection('appointments').find(query).sort({ createdAt: -1 }).skip(skip).limit(parseInt(limit)).toArray(),
      db.collection('appointments').countDocuments(query),
    ]);
    res.json({ appointments, total, totalPages: Math.ceil(total / parseInt(limit)), page: parseInt(page) });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// GET /api/appointments/doctor — doctor's appointments
router.get('/doctor', verifyToken, verifyDoctor, async (req, res) => {
  try {
    const db = getDB();
    const { page = 1, limit = 8, status } = req.query;
    const skip = (parseInt(page) - 1) * parseInt(limit);
    const query = { doctorEmail: req.user.email };
    if (status) query.appointmentStatus = status;
    const [appointments, total] = await Promise.all([
      db.collection('appointments').find(query).sort({ createdAt: -1 }).skip(skip).limit(parseInt(limit)).toArray(),
      db.collection('appointments').countDocuments(query),
    ]);
    res.json({ appointments, total, totalPages: Math.ceil(total / parseInt(limit)), page: parseInt(page) });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// GET /api/appointments/doctor/stats — doctor stats
router.get('/doctor/stats', verifyToken, verifyDoctor, async (req, res) => {
  try {
    const db = getDB();
    const email = req.user.email;
    const today = new Date().toISOString().split('T')[0];
    const [totalPatients, todayAppointments, totalReviews] = await Promise.all([
      db.collection('appointments').distinct('patientEmail', { doctorEmail: email }),
      db.collection('appointments').countDocuments({ doctorEmail: email, appointmentDate: today }),
      db.collection('reviews').countDocuments({ doctorEmail: email }),
    ]);
    res.json({ totalPatients: totalPatients.length, todayAppointments, totalReviews });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// GET /api/appointments/admin/all — admin view all
router.get('/admin/all', verifyToken, verifyAdmin, async (req, res) => {
  try {
    const db = getDB();
    const { page = 1, limit = 10 } = req.query;
    const skip = (parseInt(page) - 1) * parseInt(limit);
    const [appointments, total] = await Promise.all([
      db.collection('appointments').find().sort({ createdAt: -1 }).skip(skip).limit(parseInt(limit)).toArray(),
      db.collection('appointments').countDocuments(),
    ]);
    res.json({ appointments, total, totalPages: Math.ceil(total / parseInt(limit)) });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// PATCH /api/appointments/:id/status — update appointment status
router.patch('/:id/status', verifyToken, async (req, res) => {
  try {
    const db = getDB();
    const { appointmentStatus } = req.body;
    await db.collection('appointments').updateOne(
      { _id: new ObjectId(req.params.id) },
      { $set: { appointmentStatus, updatedAt: new Date() } }
    );
    res.json({ message: 'Status updated' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
